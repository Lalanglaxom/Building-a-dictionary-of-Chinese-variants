# Chinese Character Database Data Model



